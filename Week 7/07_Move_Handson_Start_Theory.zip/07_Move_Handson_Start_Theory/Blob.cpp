#include "Blob.h"

Blob::Blob(int size)
	: m_Size{ size }
	, m_pData{ new int[size] {} }
{
	std::cout << "Constructor, size = " << size << "\n";
	for (int i = 0; i < m_Size; i++)
	{
		m_pData[i] = rand() % 100;
	}
}

Blob::~Blob()
{
	std::cout << "Destructor\n";
	delete[] m_pData;
	m_pData = nullptr;
}

Blob::Blob(const Blob & other) 
	:m_Size{ other.m_Size }
	, m_pData{ new int[other.m_Size]{} }
{
	std::cout << "Copy constructor\n";
	for (int i = 0; i < m_Size; ++i)
	{
		m_pData[i] = other.m_pData[i];
	}
}


Blob & Blob::operator=(const Blob & rhs)
{
	if (&rhs != this)
	{
		std::cout << "Copy assignment\n";
		m_Size = rhs.m_Size;
		delete[] m_pData;
		m_pData = new int[rhs.m_Size];
		for (int i = 0; i < m_Size; ++i)
		{
			m_pData[i] = rhs.m_pData[i];
		}
	}
	return *this;
}

std::ostream & operator<<(std::ostream & out, const Blob & rhs)
{
	out << "Size = " << rhs.m_Size << "\tData: 0x" << rhs.m_pData << " ";
	for (int i = 0; i < rhs.m_Size; ++i)
	{
		out << rhs.m_pData[i] << ", ";
	}

	return out;
}
