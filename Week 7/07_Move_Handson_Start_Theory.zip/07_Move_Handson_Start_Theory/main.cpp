#include <Windows.h>
#include <iostream>
#include "Blob.h"


void StartHeapControl();
void PrintInteger(int& i);
void PrintInteger(const int& i);
void PrintInteger(int&& i);

void PrintBlob(const Blob& b);

void TestBlob();

Blob CreateBlob1(int size);
Blob CreateBlob2(int size);



int main()
{
	StartHeapControl();


	TestBlob();
}

void PrintInteger(int& i)
{
	std::cout << "l-value reference, the integer is: " << i << '\n';
}

void PrintInteger(const int&i)
{
	std::cout << "const l-value reference, the integer is: " << i << '\n';
}

void PrintInteger(int&& i)
{
	std::cout << "r-value reference, the integer is: " << i << '\n';
}

void TestBlob()
{
	Blob b1{ 10 };
	// first without move semantics

	std::cout << "Leaving TestBlob.\n\n";

}

Blob CreateBlob1(int size)
{
	Blob b{ size };
	return b; //return a l value
}

Blob CreateBlob2(int size)
{
	return Blob{ size }; // return a prvalue
}


void PrintBlob(const Blob& b)
{
	std::cout << "Blob" << b << '\n';
}

void StartHeapControl()
{
#if defined(DEBUG) | defined(_DEBUG)
	// Notify user if heap is corrupt
	HeapSetInformation(NULL, HeapEnableTerminationOnCorruption, NULL, 0);

	// Report detected leaks when the program exits
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Set a breakpoint on the specified object allocation order number
	//_CrtSetBreakAlloc( 143 );
#endif
}