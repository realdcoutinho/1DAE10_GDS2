#pragma once
class Animal
{
public:
	Animal( );
	~Animal();
	void MakeSound()const; 
};

 
