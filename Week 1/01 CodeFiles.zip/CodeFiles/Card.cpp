#include "pch.h"
#include "Card.h"
#include "Texture.h"

const int Card::minRank{ 1 };
const int Card::maxRank{ 13 };


